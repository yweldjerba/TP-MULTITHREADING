﻿
using System;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

// Classe représentant une commande
class Commande
{
    public int Id { get; set; }
    public string Client { get; set; } = "";
    public decimal Montant { get; set; }
    public bool Traitee { get; set; }
}

class Program
{
    // Connexion à MySQL avec XAMPP
    static string connectionString =
        "Server=localhost;Port=3306;Database=GestionCommandes;Uid=root;Pwd=;";

    // QUESTION 3 : Récupération des commandes non traitées
    static List<Commande> GetCommandes()
    {
        List<Commande> commandes = new List<Commande>();

        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            conn.Open();

            string sql = "SELECT Id, Client, Montant, Traitee FROM Commande WHERE Traitee = 0 ORDER BY Id";

            using (MySqlCommand cmd = new MySqlCommand(sql, conn))
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    commandes.Add(new Commande
                    {
                        Id = reader.GetInt32(0),
                        Client = reader.GetString(1),
                        Montant = reader.GetDecimal(2),
                        Traitee = reader.GetBoolean(3)
                    });
                }
            }
        }

        return commandes;
    }

    // QUESTION 4 : Traitement d'une commande
    static void TraiterCommande(Commande c)
    {
        Console.WriteLine(
            $"[{DateTime.Now:HH:mm:ss}] Début commande {c.Id} (thread {Thread.CurrentThread.ManagedThreadId})"
        );

        // Simulation d'un traitement de 10 secondes
        Thread.Sleep(10000);

        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            conn.Open();

            string sql = "UPDATE Commande SET Montant = Montant + 1, Traitee = 1 WHERE Id = @id";

            using (MySqlCommand cmd = new MySqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@id", c.Id);
                cmd.ExecuteNonQuery();
            }
        }

        Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Fin commande {c.Id}");
    }

    // QUESTION 5 : Traitement séquentiel
    static void TraiterToutesLesCommandes(List<Commande> commandes)
    {
        // Les commandes sont traitées une par une
        foreach (Commande c in commandes)
        {
            TraiterCommande(c);
        }
    }

    // QUESTION 6 : Traitement asynchrone d'une commande
    static async Task TraiterCommandeAsync(Commande c)
    {
        Console.WriteLine(
            $"[{DateTime.Now:HH:mm:ss}] Début commande {c.Id} (thread {Thread.CurrentThread.ManagedThreadId})"
        );

        // Attente de 10 secondes sans bloquer le thread
        await Task.Delay(10000);

        using (MySqlConnection conn = new MySqlConnection(connectionString))
        {
            await conn.OpenAsync();

            string sql = "UPDATE Commande SET Montant = Montant + 1, Traitee = 1 WHERE Id = @id";

            using (MySqlCommand cmd = new MySqlCommand(sql, conn))
            {
                cmd.Parameters.AddWithValue("@id", c.Id);
                await cmd.ExecuteNonQueryAsync();
            }
        }

        Console.WriteLine($"[{DateTime.Now:HH:mm:ss}] Fin commande {c.Id}");
    }

    // QUESTION 6 : Traitement de toutes les commandes en parallèle
    static async Task TraiterToutesLesCommandesAsync(List<Commande> commandes)
    {
        // Création d'une tâche par commande
        List<Task> taches = commandes
            .Select(c => TraiterCommandeAsync(c))
            .ToList();

        // Attendre la fin de toutes les tâches
        await Task.WhenAll(taches);
    }

    // Programme principal
    static async Task Main()
    {
        try
        {
            Console.WriteLine("=== TP C# MULTITHREADING ===");
            Console.WriteLine();

            // Récupération des commandes
            List<Commande> commandes = GetCommandes();

            Console.WriteLine($"{commandes.Count} commande(s) à traiter");

            if (commandes.Count == 0)
            {
                Console.WriteLine("Aucune commande à traiter.");
                return;
            }

            Console.WriteLine();
            Console.WriteLine("1 - Traitement séquentiel (Question 5)");
            Console.WriteLine("2 - Traitement parallèle (Question 6)");
            Console.WriteLine();
            Console.Write("Votre choix : ");

            string? choix = Console.ReadLine();

            if (choix != "1" && choix != "2")
            {
                Console.WriteLine("Choix invalide.");
                return;
            }

            Stopwatch sw = Stopwatch.StartNew();

            if (choix == "1")
            {
                Console.WriteLine();
                Console.WriteLine("=== TRAITEMENT SÉQUENTIEL ===");

                TraiterToutesLesCommandes(commandes);
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("=== TRAITEMENT PARALLÈLE ===");

                await TraiterToutesLesCommandesAsync(commandes);
            }

            sw.Stop();

            Console.WriteLine();
            Console.WriteLine("=== TRAITEMENT TERMINÉ ===");
            Console.WriteLine($"Durée totale : {sw.Elapsed.TotalSeconds:F1} s");
        }
        catch (Exception ex)
        {
            Console.WriteLine("Erreur : " + ex.Message);
        }
    }
}
